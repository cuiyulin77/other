# coding=utf-8

import time
import os

while True:
    os.system("scrapy crawl weixingongzhonghao_fabu1")






